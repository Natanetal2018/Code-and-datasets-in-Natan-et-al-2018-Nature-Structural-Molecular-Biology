# Script for drawing Figure 1D
# Step 1
#
# This script generates bootsrap resampled data and saves it into RData files. It is time-consuming.  The next step is run teh sript2-plot.R to generate the barplot figures in pdf. 


#cl1 dark
#cl2 soluble


rm(list=ls())


library(parallel)
no_cores <- detectCores() - 1 # get the number of CPU cores. We leave 1 free
#no_cores <- 5
cl <- makeCluster(no_cores)# , type="FORK"  works on Linux # Initiate cluster


for( case1 in c("all","shortLen","longLen","lowRelativeInterface","highRelativeInterface" ))
{
	
	ecoli.homomers.df <- read.csv("ecoli_homomers.csv", stringsAsFactors=F, header=T, row.names = NULL)
	
	
	if( case1=="all"){
		
		df5 <- ecoli.homomers.df[ ,c("PDB", "class")]
		
	}else if( case1=="shortLen"){
		
		df5 <- ecoli.homomers.df[ecoli.homomers.df$Len<median(ecoli.homomers.df$Len) ,c("PDB", "class")]
		
	}else if( case1=="longLen"){
		
		df5 <- ecoli.homomers.df[ecoli.homomers.df$Len>=median(ecoli.homomers.df $Len) ,c("PDB", "class")]
		
	}else if( case1=="lowRelativeInterface"){
		
		df5 <- ecoli.homomers.df [ecoli.homomers.df$Relative.interface < median(ecoli.homomers.df$Relative.interface) ,c("PDB", "class")]
		
	}else if( case1=="highRelativeInterface"){

		df5 <- ecoli.homomers.df[ecoli.homomers.df$Relative.interface >= median(ecoli.homomers.df$Relative.interface) ,c("PDB", "class")]
		
	}else {stop()}  
	
	
	
	#print(aggregate(df5$class, by=list(df5$class), FUN=length))
	
	
	ecoli.homomers.residues.df <- read.table("ecoli_homomers_residues.csv", stringsAsFactors=F, header=T)
	ecoli.homomers.residues.df$PDB <- sapply(ecoli.homomers.residues.df$PDB_chain, FUN= function(x) substr(x,1,nchar(x)-1)) # remove the last character
	
	ecoli.homomers.residues.df$interface <- ecoli.homomers.residues.df$SASA_in_monomer - ecoli.homomers.residues.df$SASA_in_complex
	
	BN=10000 # number of bootstrap iterations
	
	print(system.time({
						
						for(num.of.bins in c(12))
						{
							cat("num.of.bins: ",num.of.bins,"\n")
							
							ecoli.homomers.residues.df$bins <- ceiling(ecoli.homomers.residues.df$Relative_position_of_residue*num.of.bins)
							
							
							
							result1 <- list()
							
							for(j in c(2,3)) {
								
								cat( "j:",j,"\n")
								
								if(j==1){
									PDB <- unique(ecoli.homomers.residues.df$PDB)    
									result1[[j]]<-list(class.type=0)
									
								}else if(j==2){
									PDB <- unique(df5$PDB[df5$class==1])
									result1[[j]]<-list(class.type=1)
									
								} else	if(j==3){
									PDB <- unique(df5$PDB[df5$class==2])   
									result1[[j]]<-list(class.type=2)
									
								} else{
									stop()
								}
								
								
								
								# I have to export wariables to let them seen by the worker threads
								clusterExport(cl, "ecoli.homomers.residues.df") 
								clusterExport(cl, "PDB")
								
								interface_enrichment_percent_B<-parLapply(cl, 1:BN,	fun=function(i) {
											
											
											PDB.b <- sample(PDB, replace=T)
											
											df.b <- merge(ecoli.homomers.residues.df, data.frame(PDB.b), by.x="PDB", by.y="PDB.b")
											
											
											protein.df.b <- aggregate(cbind(interface,SASA_in_monomer) ~ PDB, data=df.b, sum)
											names(protein.df.b)[c(2,3)] <- paste0("sum_",names(protein.df.b)[c(2,3)])
											df.b<-merge(df.b,protein.df.b)
											
											
											df.b$interface_proportion <- df.b$interface/df.b$sum_interface
											df.b$SASA_M_proportion <- df.b$SASA_in_monomer/df.b$sum_SASA_in_monomer
											
											df.b4 <- aggregate(cbind(interface_proportion,SASA_M_proportion) ~ bins, data=df.b, sum)
											
											df.b4$interface_enrichment <- df.b4$interface_proportion/df.b4$SASA_M_proportion
											df.b4$interface_enrichment_percent <- (df.b4$interface_enrichment - mean(df.b4$interface_enrichment))
											
											return(df.b4$interface_enrichment_percent)
										})
								
								
								result1[[j]]$interface_enrichment_percent_B <-matrix(unlist(interface_enrichment_percent_B),nrow=BN,ncol=num.of.bins,byrow =TRUE)
							}
							
							save(result1,num.of.bins, file=sprintf("bootsrtrap-classAll-_bins%i-%s.Rdata",num.of.bins,case1))
							
							
							
						}
						
					}))
	
	
} # for over case1

stopCluster(cl)

cat("Done.\n")
