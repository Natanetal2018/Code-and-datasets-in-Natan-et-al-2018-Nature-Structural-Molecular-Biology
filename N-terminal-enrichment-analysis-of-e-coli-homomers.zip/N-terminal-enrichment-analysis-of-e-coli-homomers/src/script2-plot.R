# Script for drawing Figure 1D
# Step 2
#
# Before you run this script run the script1-bootsrap.R . That generates the data files ploted by this script. 


rm(list=ls())

library("stats")

add.error.bars <- function(x,low, high,w=0.1,col=1){
	arrows(x, low, x, high, code=3,angle=90,length=w,col=col);
}

for( case1 in c("all","shortLen","longLen","lowRelativeInterface","highRelativeInterface" ))
{
	
	
	num.of.bins=12
	
	cat("num.of.bins: ",num.of.bins,"\n")
	
	
	file1=sprintf("bootsrtrap-classAll-_bins%i-%s.Rdata",num.of.bins,case1)
	load( file=file1)
	
	file2=sprintf("barplotPacked-bins%i-%s.pdf",num.of.bins,case1)
	pdf(file=file2)
	
	
	b<-result1[[3]]$interface_enrichment_percent_B
	x1<-100*apply(b,2,mean)
	std.err1<-100*apply(b,2,function(x) sd(x))
	
	b<-result1[[2]]$interface_enrichment_percent_B
	x2<-100*apply(b,2,mean)
	std.err2<-100*apply(b,2,function(x) sd(x))
	
	
	h3<-barplot(rbind(x1,x2), beside=TRUE, col=c( rgb(0.1,1,0.1,0.3),rgb(0.2,0.2,0.2,0.2)) , ylim=c(-50,50) , ylab="Interface enrichment (%)", xlab="Relative position along proteins", axes=FALSE)
	add.error.bars(h3[1,],x1-std.err1,x1+std.err1,col="green",w=0.02)
	add.error.bars(h3[2,],x2-std.err2,x2+std.err2,col="gray50",w=0.02)
	abline(v=median(h3), lwd=3, lty=3, col="gray" )
	axis(2,las=2, at=seq(-100,100, by=10))
	
	
	p.values <- 1-pnorm(0,mean=x1-x2,sd=sqrt(std.err1^2+std.err2^2) )
#	p.values2<- c(p.values[c(1,2)], 1-p.values[length(p.values)+c(-1,0)])
#	p.fdr<-p.adjust(p.values2,method="fdr")
	
	star.string<-rep("",ncol(b))
	star.string[p.values<0.05] <- "*"
	star.string[p.values<0.01] <- "**"
	star.string[p.values<0.001] <- "***"
	star.string[p.values<0.0001] <- "****"
	
	star.string2<-rep("",ncol(b))
# star.string2[ p.values>0.95] <- "*"
# star.string2[ p.values>0.99] <- "**"
# star.string2[ p.values>0.999] <- "***"
# star.string2[p.values>0.9999] <- "****"
	
	
	h1<-apply(h3,2,mean)
	mtext(text=star.string,side=3,at=h1, cex=1, line=-1)
	mtext(text=star.string2,side=3,at=h1, cex=1, line=-1, col="green")
	
	box()
	dh<- h1[2]-h1[1]
	tick.positions<- c(h1[1]-dh/2 , h1+dh/2)
	labels<-seq(0,1,length.out = length(tick.positions))
	labels<-sprintf("%0.2f",labels)
	labels[1]<-"N"
	labels[length(labels)]<-"C"
	axis(side=1, at=tick.positions , labels=labels)
	
	usr=par("usr")
	text(x=0.25*usr[1]+0.75*usr[2] , y=usr[4] , labels="C-terminal half"  , adj=c(0.5,3))
	text(x=0.75*usr[1]+0.25*usr[2] , y=usr[4] , labels="N-terminal half"  , adj=c(0.5,3))
	
	
	dev.off()
	
	
	# Print results used for plotting
	df1 <- data.frame(bin = 1:length(x1), x1 = x1, x2 = x2, x1_stderr = std.err1, x2_stderr = std.err2, p = p.values)
	file3=sprintf("bootsrtap_result-bins%i-%s.csv",num.of.bins,case1)
	write.csv(df1, file3, quote = F, row.names = F)
	
}

cat("Done.\n")
